CREATE DATABASE IF NOT EXISTS company_db;
USE company_db;

CREATE TABLE IF NOT EXISTS employee (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(50) NOT NULL,
    department VARCHAR(50) NOT NULL,
    salary DOUBLE NOT NULL
);

INSERT INTO employee VALUES
(101, 'Gokul', 'IT', 35000),
(102, 'Arun', 'HR', 30000),
(103, 'Karthik', 'Java', 40000);