EMPLOYEE CRUD - JDBC + DAO + HTML/JSP

Requirements:
1. JDK 17+
2. Maven
3. MySQL
4. Apache Tomcat 10.1+
5. Eclipse/IntelliJ

SETUP:
1. Run database.sql in MySQL.
2. Open DBConnection.java.
3. Change USER/PASSWORD if needed.
4. Run: mvn clean package
5. Deploy target/EmployeeCRUD_DAO_HTML.war to Tomcat.
6. Open:
   http://localhost:8080/EmployeeCRUD_DAO_HTML/employees

LAYERS:
Model -> Employee.java
DAO -> EmployeeDAO.java
Utility -> DBConnection.java
Controller -> EmployeeServlet.java
View -> HTML/JSP/CSS

NOTE:
The edit page is intentionally kept simple in this starter package. The servlet retrieves the employee and can be switched to a JSP edit form for server-side prefilled values.
