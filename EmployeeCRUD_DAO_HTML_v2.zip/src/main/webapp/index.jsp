<%@ page import="java.util.List" %>
<%@ page import="com.example.model.Employee" %>
<!DOCTYPE html>
<html><head><title>Employee CRUD</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h1>Employee Management</h1>
<a class="btn" href="add.html">+ Add Employee</a>
<table><tr><th>ID</th><th>Name</th><th>Department</th><th>Salary</th><th>Actions</th></tr>
<%
List<Employee> employees = (List<Employee>) request.getAttribute("employees");
for(Employee e : employees) {
%>
<tr><td><%=e.getEmpId()%></td><td><%=e.getEmpName()%></td><td><%=e.getDepartment()%></td>
<td><%=e.getSalary()%></td>
<td><a href="employees?action=edit&id=<%=e.getEmpId()%>">Edit</a> |
<a href="employees?action=delete&id=<%=e.getEmpId()%>" onclick="return confirm('Delete this employee?')">Delete</a></td></tr>
<% } %>
</table></div></body></html>