<%@ page import="com.example.model.Employee" %>
<% Employee e=(Employee)request.getAttribute("employee"); %>
<!DOCTYPE html><html><head><title>Edit Employee</title><link rel="stylesheet" href="style.css"></head>
<body><div class="form-box"><h1>Edit Employee</h1>
<form action="employees" method="post">
<input type="hidden" name="action" value="update">
<label>ID</label><input type="number" name="empId" value="<%=e.getEmpId()%>" readonly>
<label>Name</label><input type="text" name="empName" value="<%=e.getEmpName()%>" required>
<label>Department</label><input type="text" name="department" value="<%=e.getDepartment()%>" required>
<label>Salary</label><input type="number" step="0.01" name="salary" value="<%=e.getSalary()%>" required>
<button type="submit">Update</button><a href="employees">Back</a>
</form></div></body></html>