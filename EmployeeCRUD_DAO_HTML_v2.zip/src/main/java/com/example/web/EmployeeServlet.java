package com.example.web;

import com.example.dao.EmployeeDAO;
import com.example.model.Employee;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {
    private final EmployeeDAO dao = new EmployeeDAO();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("delete".equals(action)) {
                dao.deleteEmployee(Integer.parseInt(req.getParameter("id")));
                resp.sendRedirect("employees");
            } else if ("edit".equals(action)) {
                req.setAttribute("employee", dao.getEmployee(Integer.parseInt(req.getParameter("id"))));
                req.getRequestDispatcher("/edit.jsp").forward(req, resp);
            } else {
                req.setAttribute("employees", dao.getAllEmployees());
                req.getRequestDispatcher("/index.jsp").forward(req, resp);
            }
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            Employee e = new Employee(
                Integer.parseInt(req.getParameter("empId")),
                req.getParameter("empName"),
                req.getParameter("department"),
                Double.parseDouble(req.getParameter("salary"))
            );
            if ("update".equals(req.getParameter("action"))) dao.updateEmployee(e);
            else dao.addEmployee(e);
            resp.sendRedirect("employees");
        } catch (SQLException | NumberFormatException ex) {
            throw new ServletException(ex);
        }
    }
}