package com.example.dao;

import com.example.model.Employee;
import com.example.util.DBConnection;
import java.sql.*;
import java.util.*;

public class EmployeeDAO {

    public void addEmployee(Employee e) throws SQLException {
        String sql = "INSERT INTO employee(emp_id, emp_name, department, salary) VALUES(?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, e.getEmpId()); ps.setString(2, e.getEmpName());
            ps.setString(3, e.getDepartment()); ps.setDouble(4, e.getSalary());
            ps.executeUpdate();
        }
    }

    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM employee ORDER BY emp_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Employee(rs.getInt("emp_id"), rs.getString("emp_name"),
                        rs.getString("department"), rs.getDouble("salary")));
            }
        }
        return list;
    }

    public Employee getEmployee(int id) throws SQLException {
        String sql = "SELECT * FROM employee WHERE emp_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next())
                    return new Employee(rs.getInt("emp_id"), rs.getString("emp_name"),
                            rs.getString("department"), rs.getDouble("salary"));
            }
        }
        return null;
    }

    public void updateEmployee(Employee e) throws SQLException {
        String sql = "UPDATE employee SET emp_name=?, department=?, salary=? WHERE emp_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getEmpName()); ps.setString(2, e.getDepartment());
            ps.setDouble(3, e.getSalary()); ps.setInt(4, e.getEmpId());
            ps.executeUpdate();
        }
    }

    public void deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM employee WHERE emp_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}